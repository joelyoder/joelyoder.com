<?php
/**
 * @package IP_Ripper
 *
 *
 * @wordpress-plugin
 * Plugin Name:       IP Ripper
 * Plugin URI:        http://joelyoder.com/
 * Description:       Easily show a visitor's IP address on a page or post.
 * Version:           1.0.0
 * Author:            Joel Yoder
 * Author URI:        http://joelyoder.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       ip-ripper
*/

// Prevent people from calling this file directly
if ( !function_exists( 'add_action' ) ) {
	echo 'Ope!  I\'m just a plugin, not much I can do when called directly.';
	exit;
}

// Register custom post type Mead Recipe
function create_meadrecipe_cpt() {

	$labels = array(
		'name'               => _x( 'Mead Recipes', 'post type general name', 'ip-ripper-textdomain' ),
		'singular_name'      => _x( 'Mead Recipe', 'post type singular name', 'ip-ripper-textdomain' ),
		'menu_name'          => _x( 'Mead Recipes', 'admin menu', 'ip-ripper-textdomain' ),
		'name_admin_bar'     => _x( 'Mead Recipe', 'add new on admin bar', 'ip-ripper-textdomain' ),
		'add_new'            => _x( 'Add New', 'Mead Recipe', 'ip-ripper-textdomain' ),
		'add_new_item'       => __( 'Add New Mead Recipe', 'ip-ripper-textdomain' ),
		'new_item'           => __( 'New Mead Recipe', 'ip-ripper-textdomain' ),
		'edit_item'          => __( 'Edit Mead Recipe', 'ip-ripper-textdomain' ),
		'view_item'          => __( 'View Mead Recipe', 'ip-ripper-textdomain' ),
		'all_items'          => __( 'All Mead Recipes', 'ip-ripper-textdomain' ),
		'search_items'       => __( 'Search Mead Recipes', 'ip-ripper-textdomain' ),
		'parent_item_colon'  => __( 'Parent Mead Recipes:', 'ip-ripper-textdomain' ),
		'not_found'          => __( 'No Mead Recipes found.', 'ip-ripper-textdomain' ),
		'not_found_in_trash' => __( 'No Mead Recipes found in Trash.', 'ip-ripper-textdomain' )
	);

	$args = array(
		'labels'             => $labels,
		'description'        => __( 'Honey wine instructions for the thirsty.', 'ip-ripper-textdomain' ),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'menu_icon'			 => 'dashicons-list-view',
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'mead-recipe' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => 25,
		'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'revisions' )
	);
	
	register_post_type( 'mead-recipe', $args );

}
add_action( 'init', 'create_meadrecipe_cpt', 0 );

function ripper_rewrite_flush() {
    // Add the custom post type from above
    create_meadrecipe_cpt();
    
    // Flush rewrite on activation so the permalinks will work
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'ripper_rewrite_flush' );


// Trigger via the [rip-ip] shortcode
function rip_ip() {
    // Check to see if the transient already exists
    if ( false === ( $ip = get_transient( 'my_public_ip' ) ) ) {

        // Yank the IP from whatismyipaddress.com
        $ip = file_get_contents('https://bot.whatismyipaddress.com');

        // Set the IP as a transient for one hour
        set_transient( 'my_public_ip', $ip, 60 * MINUTE_IN_SECONDS );
    }

    return '<p>My public IP address is: ' . get_transient( 'my_public_ip' ) . '</p>';
}
add_shortcode( 'rip-ip', 'rip_ip' );
